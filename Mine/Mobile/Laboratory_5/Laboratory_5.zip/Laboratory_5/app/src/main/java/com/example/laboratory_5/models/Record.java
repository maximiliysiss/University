package com.example.laboratory_5.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Record {
    @PrimaryKey
    String name;
    String email;
}
