#pragma once

int __stdcall WinMain();
